.mode insert
.output backup.sql
.dump
