# TODO

A list of improvements that need to be made to our application.

## Updates to the README

- [ ] Review the list of Features and consider consolidating them.
- [ ] If we want our users using Docker, should we remove the Building Manually From Source section?
- [ ] Review the First-Run checklist and make sure it's documented correctly. Update the logic when working from docker.

## General Updates

- [ ] It seems like there are a lot of unorganized files within the root directory. Can those be easily sorted / organzied without breaking the application? 

