from datetime import datetime
import secrets

from extensions import db

class Folder(db.Model):
    __tablename__ = "folder"  # keep singular to match your existing table
    __table_args__ = (
        db.UniqueConstraint("owner_user_id", "name", name="uq_folder_owner_name"),
    )

    CATEGORY_DECK = "deck"
    CATEGORY_COLLECTION = "collection"
    CATEGORY_BUILD = "build"

    id   = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), nullable=False, index=True)
    category = db.Column(
        db.String(20),
        nullable=False,
        default=CATEGORY_DECK,
        server_default=db.text(f"'{CATEGORY_DECK}'"),
        index=True,
    )

    commander_oracle_id = db.Column(db.String(128), index=True, nullable=True)
    commander_name = db.Column(db.String(200), nullable=True)
    deck_tag = db.Column(db.String(120), nullable=True, index=True)
    owner = db.Column(db.String(120), nullable=True, index=True)
    owner_user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=True, index=True)
    is_proxy = db.Column(
        db.Boolean,
        nullable=False,
        default=False,
        server_default=db.text("0"),
        index=True,
    )
    notes = db.Column(db.Text, nullable=True)
    is_public = db.Column(
        db.Boolean,
        nullable=False,
        default=False,
        server_default=db.text("0"),
        index=True,
    )
    share_token = db.Column(db.String(128), unique=True, nullable=True)

    # Relationship to Card
    cards = db.relationship(
        "Card",
        back_populates="folder",
        cascade="all, delete-orphan",
        passive_deletes=True,
    )
    owner_user = db.relationship("User", back_populates="folders")
    shares = db.relationship(
        "FolderShare",
        back_populates="folder",
        cascade="all, delete-orphan",
        passive_deletes=True,
    )
    bracket_cache = db.relationship(
        "CommanderBracketCache",
        back_populates="folder",
        cascade="all, delete-orphan",
        passive_deletes=True,
        uselist=False,
    )

    @property
    def is_collection(self) -> bool:
        return (self.category or self.CATEGORY_DECK) == self.CATEGORY_COLLECTION

    @property
    def is_deck(self) -> bool:
        return not self.is_collection

    @property
    def is_build(self) -> bool:
        return (self.category or self.CATEGORY_DECK) == self.CATEGORY_BUILD

    @property
    def is_proxy_deck(self) -> bool:
        return bool(self.is_proxy)

    def ensure_share_token(self) -> str:
        if not self.share_token:
            self.share_token = secrets.token_urlsafe(24)
        return self.share_token

    def revoke_share_token(self) -> None:
        self.share_token = None

    def __repr__(self):
        name = self.name or "Folder"
        suffix = " (proxy)" if self.is_proxy else ""
        return f"<Folder {name}{suffix}>"


class FolderShare(db.Model):
    __tablename__ = "folder_share"

    id = db.Column(db.Integer, primary_key=True)
    folder_id = db.Column(db.Integer, db.ForeignKey("folder.id", ondelete="CASCADE"), nullable=False, index=True)
    shared_user_id = db.Column(db.Integer, db.ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    created_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow, index=True)

    folder = db.relationship("Folder", back_populates="shares")
    shared_user = db.relationship("User", back_populates="shared_folders")
